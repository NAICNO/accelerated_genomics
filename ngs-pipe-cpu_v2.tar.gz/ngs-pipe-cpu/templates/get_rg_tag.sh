set -euo pipefail

# Generate read-group tag
IFS=':' read -ra READ_INFO <<< \$(zcat "${R1}" | head -n 1 | cut -d ' ' -f 1)
INSTRUMENT_ID=\${READ_INFO[2]}
RUN_ID=\${READ_INFO[3]}
FLOWCELL_ID=\${READ_INFO[0]}:\${READ_INFO[1]}

READ_GROUP="@RG\tID:\${INSTRUMENT_ID}.\${RUN_ID}\tPL:illumina\tSM:${S_NAME}\tPU:\${FLOWCELL_ID}"
